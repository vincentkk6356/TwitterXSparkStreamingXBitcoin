package Setting;


import java.io.FileReader;

public class configReader {

    static String BOOTSTRAP_SERVERS = null;
    static String CONSUMER_GROUP =  null;
    static String KAFKA_TOPIC =  null;
    static String CORE_SITE_PATH =  null;
    static String HDFS_SITE_PATH =  null;
    static String HDFS_SERVER =  null;
    static String TMP_DIR =  null;
    static String FINAL_DIR =  null;
    static String BATCH_DURATION = null;
    static String MERGE_INTERVAL = null;

    public static void main (String arg[]){
        try(FileReader reader =  new FileReader("/Users/kaikin/Desktop/CS Master/COMP7305 Cluster and cloud computing/Project/comgroup11tweet/src/main/java/Setting/config")) {
            java.util.Properties properties = new java.util.Properties();
            properties.load(reader);


            BOOTSTRAP_SERVERS = properties.getProperty("BOOTSTRAP_SERVERS");
            CONSUMER_GROUP =  properties.getProperty("CONSUMER_GROUP");
            KAFKA_TOPIC =  properties.getProperty("KAFKA_TOPIC");
            CORE_SITE_PATH =  properties.getProperty("CORE_SITE_PATH");
            HDFS_SITE_PATH =  properties.getProperty("HDFS_SITE_PATH");
            HDFS_SERVER =  properties.getProperty("HDFS_SERVER");
            TMP_DIR =  properties.getProperty("TMP_DIR");
            FINAL_DIR =  properties.getProperty("FINAL_DIR");
            BATCH_DURATION =  properties.getProperty("BATCH_DURATION");
            MERGE_INTERVAL =  properties.getProperty("MERGE_INTERVAL");



        }catch (Exception e) {
            e.printStackTrace();
            return;
        }
        System.out.println(java.time.LocalDate.now());
    }
}
