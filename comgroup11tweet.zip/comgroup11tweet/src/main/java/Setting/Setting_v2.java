package Setting;

public class Setting_v2 {

    public static final String BOOTSTRAP_SERVERS= "student30-x1:9030,student30-x2:9033,student31-x1:9031,student31-x2:9312,student32-x1:9032,student32-x2:9322,student59-x1:9551,student59-x2:9552";
    public static final String CONSUMER_GROUP= "group11";
    public static final String KAFKA_TOPIC= "twitter_alpha";
    public static final String CORE_SITE_PATH= "/opt/hadoop-2.7.5/etc/hadoop/core-site.xml";
    public static final String HDFS_SITE_PATH= "/opt/hadoop-2.7.5/etc/hadoop/hdfs-site.xml";
    public static final String DEST= "hdfs://student59:9000/twitter_sentiment_bitcoin/";
    public static final String RAWPATH= "hdfs://student59:9000/twitter_sentiment_bitcoin/";
    public static final String hdfsServer= "hdfs://student59:9000/";
    public static final String INTERMEDIATEPATH= "hdfs://student59:9000/final";
    public static final String FINALPATH= "hdfs://student59:9000/merged";


}
