package Hive;
import java.sql.*;

public class HiveLoader {


    public void Loaddata() throws ClassNotFoundException{
        System.out.println("Testing Hive connection");
        Class.forName("org.apache.hive.jdbc.HiveDriver");
        try{
            Connection con = DriverManager.getConnection("jdbc:hive2://202.45.128.135:16859/default","root","root");
            Statement sta = con.createStatement();
            String sql = "LOAD DATA INPATH '/merged/*' INTO TABLE b_result2";
            ResultSet result = sta.executeQuery(sql);
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }
}
