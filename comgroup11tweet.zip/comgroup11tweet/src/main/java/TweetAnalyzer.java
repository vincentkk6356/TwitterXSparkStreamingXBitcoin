import Setting.Setting;
import org.apache.hadoop.fs.FileSystem;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.SparkConf;
import urlReader.urlReader;
import org.apache.spark.streaming.Durations;

import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.json.JSONObject;
import org.apache.spark.streaming.kafka010.*;

import java.io.IOException;
import java.util.*;
import Sentiment.SentimentAnalyzer;
import hdfsWriter.hdfsWriter;


public class TweetAnalyzer {

    private static long startTime = System.currentTimeMillis();

    private static String dataSet = "";

    private static String price = "";

    private static void  setPrintString(String s){
        dataSet += s;
    }

    private static String getPrintString(){
        return  dataSet;
    }

    private static void setPrice(String p){
        price = p;
    }
//    private static void writeCSV() throws IOException {
//        FileWriter writer = new FileWriter("/Users/kaikin/test.csv", true);
//        Date date = new Date();
//        writer.append(dataSet);
//        writer.flush();
//        writer.close();
//        dataSet ="";
//    }




    public static void main(String[] args) throws InterruptedException, IOException {

        // Create a local StreamingContext with two working thread and batch interval of 1 second
        SparkConf conf = new SparkConf().setMaster("yarn").setAppName("tweet");
        JavaStreamingContext jssc = new JavaStreamingContext(conf, Durations.seconds(10));


        Map<String, Object> kafkaParams = new HashMap<>();
        kafkaParams.put("bootstrap.servers", Setting.BOOTSTRAP_SERVERS);
        kafkaParams.put("key.deserializer", StringDeserializer.class);
        kafkaParams.put("value.deserializer", StringDeserializer.class);
        kafkaParams.put("group.id", Setting.CONSUMER_GROUP);

        Collection<String> topics = Arrays.asList("twitter_alpha");

       FileSystem fs = hdfsWriter.configureFileSystem(Setting.CORE_SITE_PATH,Setting.HDFS_SITE_PATH );

       hdfsWriter.checkAndCreate(fs,Setting.DEST + urlReader.getHostName()+ ".txt");

        urlReader.getHostName();
        setPrice(urlReader.getPrice());

        JavaInputDStream<ConsumerRecord<String, String>> kafkaStream =
                KafkaUtils.createDirectStream(
                        jssc,
                        LocationStrategies.PreferConsistent(),
                        ConsumerStrategies.<String, String>Subscribe(topics, kafkaParams)
                );

                    kafkaStream.foreachRDD(rdd -> {
                        rdd.foreach(record -> {

                            //Get the "text" field of every tweet and save it in variable "dataSet" for future I/O
                            final JSONObject root = new JSONObject(record.value());
                            final String text = root.getString("text");
                            final String date_raw = root.getString("created_at");
                            String date = date_raw.substring(0,10);
                            String time = date_raw.substring(11,19);
                            System.out.println(date);
                            System.out.println(time);
                            System.out.println(text);



                            //chk time & update Bitcoin price if necessary
                            if (urlReader.checkTime(System.currentTimeMillis(), startTime)){
                                price = urlReader.getPrice();
                                startTime = System.currentTimeMillis();
//                                System.out.println("------- Price UPDATED------");
                            }


                            SentimentAnalyzer t = new SentimentAnalyzer();
                            t.findSentiment(text);
                            int sentiment = t.final_senti();
                            System.out.println(sentiment);

                            setPrintString(date + "," + time + "," + price + "," + sentiment + "\n");


                            //for DEBUGGING
//                        System.out.println( "{" + record.key() + ":[" +record.value() +"]}");
//                        System.out.println("This is a List:" + record.key() + "--End of list");
//                        System.out.println("This is a List:" + record.value() + "--End of list");
//                        System.out.println(wholeTweet.length());

//                        System.out.println(System.currentTimeMillis() + text);
//                        System.out.println("List:" + wholeTweet.getJSONObject(3) + "-------");
//                        System.out.println(getString());





                        });

                        //write to hdfs as csv
//                        writeCSV();
                        hdfsWriter.appendToFile(fs,dataSet,Setting.DEST);

                    });


        jssc.start();
        jssc.awaitTermination();
        hdfsWriter.closeFileSystem(fs);
        System.out.println("Shutting Down......");
}
    }