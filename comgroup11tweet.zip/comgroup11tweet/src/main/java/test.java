import Sentiment.SentimentAnalyzer;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class test {
    public static void main (String arg[]){
//        String text="hello,hi";
//        SentimentAnalyzer t = new SentimentAnalyzer();
//        t.findSentiment(text);
//        int sentiment = t.final_senti();


        InetAddress ip;
        String hostname;
        try {
            ip = InetAddress.getLocalHost();
            hostname = ip.getHostName();
            System.out.println("Your current IP address : " + ip);
            System.out.println("Your current Hostname : " + hostname);

        } catch (UnknownHostException e) {

            e.printStackTrace();
        }

    }
}
