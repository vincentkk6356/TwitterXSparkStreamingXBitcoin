package Sentiment;

import java.util.ArrayList;
import java.util.List;

import java.util.Properties;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations.SentimentAnnotatedTree;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.util.CoreMap;


public class SentimentAnalyzer {
	public List<Integer> senti;
	
	public void findSentiment(String line) {
		senti = new ArrayList<>();
		
        Properties props = new Properties();
        props.setProperty("annotators", "tokenize, ssplit, parse, sentiment");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
        int mainSentiment = 0;
        if (line != null && line.length() > 0) {
            int longest = 0;
            Annotation annotation = pipeline.process(line);
            for (CoreMap sentence : annotation.get(CoreAnnotations.SentencesAnnotation.class)) {
                Tree tree = sentence.get(SentimentAnnotatedTree.class);
                int sentiment = RNNCoreAnnotations.getPredictedClass(tree);
                String partText = sentence.toString();
                if (partText.length() > longest) {
                    mainSentiment = sentiment;
                    senti.add(mainSentiment);
                    longest = partText.length();
                }

            }
        }
       // if (mainSentiment == 2 || mainSentiment > 4 || mainSentiment < 0) {
        //    return null;
        //}
    }
	public double avg_senti(){
		double total=0;
		Iterator<Integer> it = senti.iterator();
		while(it.hasNext()) {
			Integer cr = it.next();
			total+=(double)cr;
		}
		
		return ((total/senti.size())-2)/2;
		
	}
	
	public Integer final_senti(){
		Map<Integer, Integer> score = new HashMap<Integer, Integer>();
		Integer number,r1,r2;
		r1=0;
		r2=0;
		Iterator<Integer> it = senti.iterator();
	try{	
		
		while(it.hasNext()) {
			Integer cr = it.next();
			if (score.isEmpty()){
				score.put(cr, 1);
			}
			else{
				Integer st = score.get(cr);	
				if (st == null) {
					score.put(cr, 1);
				}
				
				else {
					number=score.get(cr);
					number++;
					score.put(cr,number);
				}
			}

		//System.out.println(cr+""+score.get(cr));	
		}
		Set<Entry<Integer, Integer>> entrySet = score.entrySet();
		for (Entry<Integer, Integer> entry : entrySet) {
			if(entry.getValue()>r2){
				r1=entry.getKey();
				r2= entry.getValue();
			}
		}

		
		
	}catch(Exception e){
		e.printStackTrace();
	}
	return r1;
		
	}
}
