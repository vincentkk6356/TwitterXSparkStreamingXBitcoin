import urlReader.urlReader;

public class Setting {

    public static final String BOOTSTRAP_SERVERS= "student30-x1:9030,student31-x1:9031,student32-x1:9032";
    public static final String CONSUMER_GROUP= "group11";
    public static final String KAFKA_TOPIC= "twitter_alpha";
    public static final String CORE_SITE_PATH= "$HADOOP_HOME/etc/hadoop/core-site.xml";
    public static final String HDFS_SITE_PATH= "$HADOOP_HOME/etc/hadoop/hdfs-site.xml";
    public static final String DEST= "hdfs://student59:9000/twitter_sentiment_bitcoin/" + urlReader.getHostName() + ".txt";
}
