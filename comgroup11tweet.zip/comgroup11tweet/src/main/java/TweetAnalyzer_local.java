import Sentiment.SentimentAnalyzer;
import Setting.Setting_v2;
import hdfsWriter.hdfsWriter;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.rdd.RDD;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.Time;
import org.apache.spark.streaming.api.java.*;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;
import org.json.JSONObject;
import scala.Array;
import scala.Function1;
import scala.Function2;
import scala.Tuple2;
import scala.runtime.BoxedUnit;
import urlReader.urlReader;

import java.io.FileReader;
import java.io.IOException;
import java.time.Instant;
import java.util.*;


public class TweetAnalyzer_local {

//    private static long startTime = System.currentTimeMillis();
    private static Instant start = Instant.now();

    private static Date date = new Date();

    private static String dataSet = "";

    private static String price = "";

    private static void  setPrintString(String s){
        dataSet += s;
    }

    private static String getPrintString(){
        return  dataSet;
    }

    private static void setPrice(String p){
        price = p;
    }
//    private static void writeCSV() throws IOException {
//        FileWriter writer = new FileWriter("/Users/kaikin/test.csv", true);
//        Date date = new Date();
//        writer.append(dataSet);
//        writer.flush();
//        writer.close();
//        dataSet ="";
//    }


    static String BOOTSTRAP_SERVERS = null;
    static String CONSUMER_GROUP =  null;
    static String KAFKA_TOPIC =  null;
    static String CORE_SITE_PATH =  null;
    static String HDFS_SITE_PATH =  null;
    static String HDFS_SERVER =  null;
    static String TMP_DIR =  null;
    static String FINAL_DIR =  null;
    static String BATCH_DURATION = null;
    static String MERGE_INTERVAL = null;

    public static void main(String[] args) throws InterruptedException, IOException {

        if (args.length != 1){

            System.out.println("Please specific the configure file's path!");
            return;
        }
        //Load Configuration


        try(FileReader reader =  new FileReader(args[0])) {
            java.util.Properties properties = new java.util.Properties();
            properties.load(reader);

             BOOTSTRAP_SERVERS = properties.getProperty("BOOTSTRAP_SERVERS");
             CONSUMER_GROUP =  properties.getProperty("CONSUMER_GROUP");
             KAFKA_TOPIC =  properties.getProperty("KAFKA_TOPIC");
             CORE_SITE_PATH =  properties.getProperty("CORE_SITE_PATH");
             HDFS_SITE_PATH =  properties.getProperty("HDFS_SITE_PATH");
             HDFS_SERVER =  properties.getProperty("HDFS_SERVER");
             TMP_DIR =  properties.getProperty("TMP_DIR");
             FINAL_DIR =  properties.getProperty("FINAL_DIR");
             BATCH_DURATION =  properties.getProperty("BATCH_DURATION");
             MERGE_INTERVAL =  properties.getProperty("MERGE_INTERVAL");



        }catch (Exception e) {
            e.printStackTrace();
            System.out.println("Wrong Configuration!");
            return;
        }

        System.out.println("BATCH_DURATION: " +  BATCH_DURATION);
        System.out.println("MERGE_INTERVAL: " +  MERGE_INTERVAL);
        System.out.println("BOOTSTRAP_SERVERS: " +  BOOTSTRAP_SERVERS);
        System.out.println("CONSUMER_GROUP: " +  CONSUMER_GROUP);
        System.out.println("KAFKA_TOPIC: " +  KAFKA_TOPIC);
        int BATCH_DURATION_INT = Integer.parseInt(BATCH_DURATION);

        // Create a local StreamingContext with two working thread and batch interval of n second
        SparkConf conf = new SparkConf().setAppName("tweet");
        JavaStreamingContext jssc = new JavaStreamingContext(conf, Durations.seconds(BATCH_DURATION_INT));


        Map<String, Object> kafkaParams = new HashMap<>();
        kafkaParams.put("bootstrap.servers", BOOTSTRAP_SERVERS);
        kafkaParams.put("key.deserializer", StringDeserializer.class);
        kafkaParams.put("value.deserializer", StringDeserializer.class);
        kafkaParams.put("group.id", CONSUMER_GROUP);

        Collection<String> topics = Arrays.asList(KAFKA_TOPIC);

//       FileSystem fs = hdfsWriter.configureFileSystem("/usr/local/Cellar/hadoop/3.0.0/libexec/etc/hadoop/core-site.xml","/usr/local/Cellar/hadoop/3.0.0/libexec/etc/hadoop/hdfs-site.xml" );
//        hdfsWriter.checkAndCreate(fs,"hdfs://localhost:9000/users/test.txt");
//
//        urlReader.getHostName();
//        setPrice(urlReader.getPrice());

        JavaInputDStream<ConsumerRecord<String, String>> kafkaStream =
                KafkaUtils.createDirectStream(
                        jssc,
                        LocationStrategies.PreferConsistent(),
                        ConsumerStrategies.<String, String>Subscribe(topics, kafkaParams)
                );

           JavaDStream dstream = kafkaStream.mapToPair(record -> new Tuple2<>(record.key(), record.value())).map(record -> record._2());
          JavaPairDStream d2stream = dstream.mapToPair(record-> new Tuple2<>(new JSONObject(record.toString()).getString("created_at"),new JSONObject(record.toString()).getString("text") ));
        JavaDStream d3stream = d2stream.map(new Function<Tuple2, Tuple2>() {
            @Override
            public Tuple2 call(Tuple2 s) {
                SentimentAnalyzer t = new SentimentAnalyzer();
                            t.findSentiment(s._2().toString());
                            int sentiment = t.final_senti();
                return new Tuple2<>(s._1().toString() , Integer.toString(sentiment)) ;}
        });

        JavaDStream d4stream = d3stream.map(new Function<Tuple2, String>() {
            @Override
            public String call(Tuple2 s) throws IOException {
                String date = s._1().toString().substring(0,10);
                String time = s._1().toString().substring(11,19);

                return (date + "," + time + "," + s._2().toString() + "," + urlReader.getPrice())  ;}
        });

d4stream.print();
//d4stream.dstream().saveAsTextFiles("hdfs://student59:9000/dumb-", "-folder");
  d4stream.dstream().foreachRDD(new Function2<RDD, Time, BoxedUnit>() {
    @Override
    public BoxedUnit apply(RDD rdd, Time time) {
        try {
            //Debug
            System.out.println(rdd.toString());
            System.out.println(rdd.isEmpty());
            //Write into hdfs as csv file
            System.out.println("HERE IS THE rdd CONTENT:  " + rdd.collect().toString());

            hdfsWriter.saveAsTextAppend(HDFS_SERVER, rdd, java.time.LocalDate.now() + "_" + System.currentTimeMillis() + ".csv", CORE_SITE_PATH, HDFS_SITE_PATH );

            if (hdfsWriter.chkIfMerge(start, Integer.parseInt(MERGE_INTERVAL))){
                System.out.println("----------MERGE ALL---------");
                hdfsWriter.merge(TMP_DIR,FINAL_DIR , java.time.LocalDate.now() + "_" + System.currentTimeMillis() + ".csv", true, CORE_SITE_PATH, HDFS_SITE_PATH  );
                start = Instant.now();
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("FAIL TO APPEND!!!");
        }


        return null;
    }

    @Override
    public Function1<RDD, Function1<Time, BoxedUnit>> curried() {
        return null;
    }

    @Override
    public Function1<Tuple2<RDD, Time>, BoxedUnit> tupled() {
        return null;
    }

    @Override
    public boolean apply$mcZDD$sp(double v, double v1) {
        return false;
    }

    @Override
    public double apply$mcDDD$sp(double v, double v1) {
        return 0;
    }

    @Override
    public float apply$mcFDD$sp(double v, double v1) {
        return 0;
    }

    @Override
    public int apply$mcIDD$sp(double v, double v1) {
        return 0;
    }

    @Override
    public long apply$mcJDD$sp(double v, double v1) {
        return 0;
    }

    @Override
    public void apply$mcVDD$sp(double v, double v1) {

    }

    @Override
    public boolean apply$mcZDI$sp(double v, int i) {
        return false;
    }

    @Override
    public double apply$mcDDI$sp(double v, int i) {
        return 0;
    }

    @Override
    public float apply$mcFDI$sp(double v, int i) {
        return 0;
    }

    @Override
    public int apply$mcIDI$sp(double v, int i) {
        return 0;
    }

    @Override
    public long apply$mcJDI$sp(double v, int i) {
        return 0;
    }

    @Override
    public void apply$mcVDI$sp(double v, int i) {

    }

    @Override
    public boolean apply$mcZDJ$sp(double v, long l) {
        return false;
    }

    @Override
    public double apply$mcDDJ$sp(double v, long l) {
        return 0;
    }

    @Override
    public float apply$mcFDJ$sp(double v, long l) {
        return 0;
    }

    @Override
    public int apply$mcIDJ$sp(double v, long l) {
        return 0;
    }

    @Override
    public long apply$mcJDJ$sp(double v, long l) {
        return 0;
    }

    @Override
    public void apply$mcVDJ$sp(double v, long l) {

    }

    @Override
    public boolean apply$mcZID$sp(int i, double v) {
        return false;
    }

    @Override
    public double apply$mcDID$sp(int i, double v) {
        return 0;
    }

    @Override
    public float apply$mcFID$sp(int i, double v) {
        return 0;
    }

    @Override
    public int apply$mcIID$sp(int i, double v) {
        return 0;
    }

    @Override
    public long apply$mcJID$sp(int i, double v) {
        return 0;
    }

    @Override
    public void apply$mcVID$sp(int i, double v) {

    }

    @Override
    public boolean apply$mcZII$sp(int i, int i1) {
        return false;
    }

    @Override
    public double apply$mcDII$sp(int i, int i1) {
        return 0;
    }

    @Override
    public float apply$mcFII$sp(int i, int i1) {
        return 0;
    }

    @Override
    public int apply$mcIII$sp(int i, int i1) {
        return 0;
    }

    @Override
    public long apply$mcJII$sp(int i, int i1) {
        return 0;
    }

    @Override
    public void apply$mcVII$sp(int i, int i1) {

    }

    @Override
    public boolean apply$mcZIJ$sp(int i, long l) {
        return false;
    }

    @Override
    public double apply$mcDIJ$sp(int i, long l) {
        return 0;
    }

    @Override
    public float apply$mcFIJ$sp(int i, long l) {
        return 0;
    }

    @Override
    public int apply$mcIIJ$sp(int i, long l) {
        return 0;
    }

    @Override
    public long apply$mcJIJ$sp(int i, long l) {
        return 0;
    }

    @Override
    public void apply$mcVIJ$sp(int i, long l) {

    }

    @Override
    public boolean apply$mcZJD$sp(long l, double v) {
        return false;
    }

    @Override
    public double apply$mcDJD$sp(long l, double v) {
        return 0;
    }

    @Override
    public float apply$mcFJD$sp(long l, double v) {
        return 0;
    }

    @Override
    public int apply$mcIJD$sp(long l, double v) {
        return 0;
    }

    @Override
    public long apply$mcJJD$sp(long l, double v) {
        return 0;
    }

    @Override
    public void apply$mcVJD$sp(long l, double v) {

    }

    @Override
    public boolean apply$mcZJI$sp(long l, int i) {
        return false;
    }

    @Override
    public double apply$mcDJI$sp(long l, int i) {
        return 0;
    }

    @Override
    public float apply$mcFJI$sp(long l, int i) {
        return 0;
    }

    @Override
    public int apply$mcIJI$sp(long l, int i) {
        return 0;
    }

    @Override
    public long apply$mcJJI$sp(long l, int i) {
        return 0;
    }

    @Override
    public void apply$mcVJI$sp(long l, int i) {

    }

    @Override
    public boolean apply$mcZJJ$sp(long l, long l1) {
        return false;
    }

    @Override
    public double apply$mcDJJ$sp(long l, long l1) {
        return 0;
    }

    @Override
    public float apply$mcFJJ$sp(long l, long l1) {
        return 0;
    }

    @Override
    public int apply$mcIJJ$sp(long l, long l1) {
        return 0;
    }

    @Override
    public long apply$mcJJJ$sp(long l, long l1) {
        return 0;
    }

    @Override
    public void apply$mcVJJ$sp(long l, long l1) {

    }
});


//        d4stream.foreachRDD(rdd -> {
//            System.out.println(rdd);
//            FileSystem fs = hdfsWriter.configureFileSystem("/usr/local/Cellar/hadoop/3.0.0/libexec/etc/hadoop/core-site.xml","/usr/local/Cellar/hadoop/3.0.0/libexec/etc/hadoop/hdfs-site.xml" );
//        hdfsWriter.checkAndCreate(fs,"hdfs://localhost:9000/users/test.txt");
////        urlReader.getHostName();
//            hdfsWriter.appendToFile(fs,dataSet,"hdfs://localhost:9000/users/test.txt");
//            hdfsWriter.closeFileSystem(fs);
//        });



//           JavaDStream d3stream = d2stream.map(record-> record._2());
//           JavaPairDStream d3stream = d2stream.mapToPair(record -> new Tuple2(record. , new SentimentAnalyzer().findSentiment(record.))
//        JavaDStream splitedStream = kafkaStream.repartition(2);
//                    kafkaStream. foreachRDD(rdd -> {
//                        rdd.foreach(record -> {
//
//                            //Get the "text" field of every tweet and save it in variable "dataSet" for future I/O
//                            final JSONObject root = new JSONObject(record.value());
//                            final String text = root.getString("text");
//                            final String date_raw = root.getString("created_at");
//                            String date = date_raw.substring(0,10);
//                            String time = date_raw.substring(11,19);
//                            System.out.println(date);
//                            System.out.println(time);
//
//
//                            System.out.println(System.currentTimeMillis() + " vs " + startTime);
//                            //chk time & update Bitcoin price if necessary
//                            if (urlReader.checkTime(System.currentTimeMillis(), startTime)){
//                                price = urlReader.getPrice();
//                                startTime = System.currentTimeMillis();
////                                System.out.println("------- Price UPDATED------");
//                            }
//
//
//                            SentimentAnalyzer t = new SentimentAnalyzer();
//                            t.findSentiment(text);
//                            int sentiment = t.final_senti();
//                            System.out.println(sentiment);
//
//                            setPrintString(date + "," + time + "," + price + "," + sentiment + "\n");


                            //for DEBUGGING
//                        System.out.println( "{" + record.key() + ":[" +record.value() +"]}");
//                        System.out.println("This is a List:" + record.key() + "--End of list");
//                        System.out.println("This is a List:" + record.value() + "--End of list");
//                        System.out.println(wholeTweet.length());

//                        System.out.println(System.currentTimeMillis() + text);
//                        System.out.println("List:" + wholeTweet.getJSONObject(3) + "-------");
//                        System.out.println(getString());





//                        });

                        //write to hdfs as csv
//                        writeCSV();
//                        hdfsWriter.appendToFile(fs,dataSet,"hdfs://localhost:9000/users/test.txt");

//                    });


        jssc.start();


        jssc.awaitTermination();
//        hdfsWriter.closeFileSystem(fs);
        System.out.println("Shutting Down......");
}
    }