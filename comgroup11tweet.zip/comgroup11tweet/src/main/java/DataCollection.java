import Setting.Setting;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;




public class DataCollection {

    public static String DataSet;

    public static void setData(String s){
        DataSet += s;

    }

    public static void clearData(){
        DataSet = "";

    }

    public static void main(String[] args) throws InterruptedException, IOException {

        // Create a local StreamingContext with two working thread and batch interval of 1 second
        SparkConf conf = new SparkConf().setMaster("local[*]").setAppName("tweet");
        JavaStreamingContext jssc = new JavaStreamingContext(conf, Durations.seconds(10));


        Map<String, Object> kafkaParams = new HashMap<>();
        kafkaParams.put("bootstrap.servers", "localhost:9092");
        kafkaParams.put("key.deserializer", StringDeserializer.class);
        kafkaParams.put("value.deserializer", StringDeserializer.class);
        kafkaParams.put("group.id", Setting.CONSUMER_GROUP);

        Collection<String> topics = Arrays.asList("twitter_alpha");


        JavaInputDStream<ConsumerRecord<String, String>> kafkaStream =
                KafkaUtils.createDirectStream(
                        jssc,
                        LocationStrategies.PreferConsistent(),
                        ConsumerStrategies.<String, String>Subscribe(topics, kafkaParams)
                );

        kafkaStream.foreachRDD(rdd -> {
            rdd.foreach(record -> {
                String s = record.value().toString().substring(0,1) + "\"bitcoin_price\":" + urlReader.urlReader.getPrice() + "," + record.value().toString().substring(1,record.value().toString().length()) + "\n";
                setData(s);


            });

            try
            {
                String filename= "/Users/kaikin/data.txt";
                FileWriter fw = new FileWriter(filename,true); //the true will append the new data
                fw.write(DataSet);//appends the string to the file
                fw.close();
                clearData();
            }
            catch(IOException ioe)
            {
                System.err.println("IOException: " + ioe.getMessage());
            }
        });


        jssc.start();
        jssc.awaitTermination();
    }
}
