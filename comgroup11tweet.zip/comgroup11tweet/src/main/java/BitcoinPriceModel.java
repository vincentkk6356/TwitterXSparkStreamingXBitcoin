import Sentiment.SentimentAnalyzer;
import hdfsWriter.hdfsWriter;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.rdd.RDD;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.Time;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;
import org.json.JSONObject;
import scala.*;
import scala.runtime.BoxedUnit;
import urlReader.urlReader;

import java.io.FileReader;
import java.io.IOException;
import java.time.Instant;
import java.util.*;

public class BitcoinPriceModel {



        public static void main(String[] args) throws InterruptedException, IOException {

            if (args.length != 1){

                System.out.println("Please specific the data file's path!");
                return;
            }

            SparkSession spark = SparkSession
                    .builder()
                    .appName("BitcoinModel")
                    .getOrCreate();



            JavaRDD<String> tweet = spark.read().textFile(args[0]).javaRDD();



            JavaRDD<Tuple4> record = tweet.map(new Function<String, Tuple4>() {
                @Override
                public Tuple4 call(String s) throws Exception {
                    String date = new JSONObject(s).getString("created_at").substring(0,10);
                    String time = new JSONObject(s).getString("created_at").substring(11,19);
                    String text = new JSONObject(s).getString("text");
                    String price = new JSONObject(s).getString("bitcoin_price");
                    return new Tuple4<String,String,String,String>(date,time,text, price) ;}
            });


            JavaRDD<Tuple4> filtered = record.map(new Function<Tuple4, Tuple4>() {
                @Override
                public Tuple4 call(Tuple4 s) throws Exception {
                    SentimentAnalyzer t = new SentimentAnalyzer();
                    t.findSentiment(s._3().toString());
                    int sentiment = t.final_senti();
                    return new Tuple4<String,String,String,String>(s._1().toString(),s._2().toString(),Integer.toString(sentiment), s._4().toString()) ;}
            });



            spark.stop();
            System.out.println("Shutting Down......");
        }
    }

