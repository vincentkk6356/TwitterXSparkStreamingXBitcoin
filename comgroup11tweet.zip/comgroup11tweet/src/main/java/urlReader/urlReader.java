package urlReader;


import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Date;

public class urlReader {


    public static boolean checkTime(long currentTime, long startTime){
        if(currentTime-startTime > 60*15*100){
            return true;
        }
        return false;
    }

    public static String getHostName(){
        InetAddress ip;
        String hostname;
        try {
            ip = InetAddress.getLocalHost();
            hostname = ip.getHostName();
            System.out.println("Your current IP address : " + ip);
            System.out.println("Your current Hostname : " + hostname);
            return hostname;

        } catch (UnknownHostException e) {

            e.printStackTrace();
            return "NoHost";
        }

    }

    public static String getPrice() throws IOException {
        String sURL = "https://blockchain.info/ticker"; //just a string

        // Connect to the URL using java's native library
        URL url = new URL(sURL);
        HttpURLConnection request = (HttpURLConnection) url.openConnection();
        request.connect();

        // Convert to a JSON object to print data
        JsonParser jp = new JsonParser(); //from gson
        JsonElement root = jp.parse(new InputStreamReader((InputStream) request.getContent())); //Convert the input stream to a json element
        JsonObject rootobj = root.getAsJsonObject(); //May be an array, may be an object.
        JsonObject USD = rootobj.get("USD").getAsJsonObject();
        String price = USD.get("last").getAsString();

        return price;
    }
}
