package hdfsWriter;
import Setting.Setting;
import Setting.Setting_v2;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DFSClient;
import org.apache.spark.rdd.RDD;
import org.apache.spark.streaming.Time$;
import urlReader.urlReader;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;
import java.time.Instant;

public class hdfsWriter {


    public static FileSystem configureFileSystem(String coreSitePath, String hdfsSitePath) {
        FileSystem fileSystem = null;
        try {
            Configuration conf = new Configuration();
            conf.setBoolean("dfs.support.append", true);
            Path coreSite = new Path(coreSitePath);
            Path hdfsSite = new Path(hdfsSitePath);
            conf.addResource(coreSite);
            conf.addResource(hdfsSite);
            fileSystem = FileSystem.get(conf);
        } catch (IOException ex) {
            System.out.println("Error occurred while configuring FileSystem");
        }
        return fileSystem;
    }

    public static void checkAndCreate(FileSystem fileSystem, String dest) throws IOException {

        Path destPath = new Path(dest);
        if (!fileSystem.exists(destPath)) {
//            System.err.println("File doesn't exist");
//            return "Failure";
            System.out.println("File created!");
            fileSystem.createNewFile(destPath);
        }
        System.out.println("File Checked!");
    }


    public static void checkAndCreateDir(FileSystem fileSystem, String dest) throws IOException {

        Path destPath = new Path(dest);
        if (!fileSystem.exists(destPath)) {
//            System.err.println("File doesn't exist");
//            return "Failure";
            System.out.println("Folder created!");
            fileSystem.mkdirs(destPath);

        }
        System.out.println("Folder Checked!");
    }


    public static void appendToFile(FileSystem fileSystem, String content, String dest) throws IOException {

        Path destPath = new Path(dest);
        Boolean isAppendable = Boolean.valueOf(fileSystem.getConf().get("dfs.support.append"));
        if(isAppendable) {
            FSDataOutputStream fs_append = fileSystem.append(destPath);
            PrintWriter writer = new PrintWriter(fs_append);
            writer.append(content);
            writer.flush();
            fs_append.hflush();
            writer.close();
            fs_append.close();
            System.out.println("---Write Successful---");
        }
        else {
            System.err.println("Please set the dfs.support.append property to true");
        }
    }


    public static void closeFileSystem(FileSystem fileSystem){
        try {
            fileSystem.close();
        }
        catch (IOException ex){
            System.out.println("----------Could not close the FileSystem----------");
        }
    }

    public static void saveAsTextAppend(String hdfsServer,RDD rdd, String fileName,String coreSitePath, String hdfsSitePath ){

        try {
            String srcPath = hdfsServer + "/tmp/tweet_bitcoin";

            rdd.saveAsTextFile(srcPath);
            //Debug
            System.out.println("Raw Data: " + rdd.toString());
            System.out.println("Saved Raw Data!");

            String dstPath = hdfsServer + "/final";
            merge(srcPath, dstPath, fileName, false, coreSitePath, hdfsSitePath);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void merge(String srcPath, String dstPath, String fileName, Boolean deleteSrc , String coreSitePath, String hdfsSitePath) throws IOException {
        FileSystem hdfs = null;
        Configuration conf = null;
        try {
            conf = new Configuration();
            conf.setBoolean("dfs.support.append", true);
            Path coreSite = new Path(coreSitePath);
            Path hdfsSite = new Path(hdfsSitePath);
            conf.addResource(coreSite);
            conf.addResource(hdfsSite);
            hdfs = FileSystem.get(conf);

            //Debug
            System.out.println("Configured hdfs Sucessfully");

        } catch (IOException e) {
            System.out.println("Error occurred while configuring FileSystem");
        }
         checkAndCreateDir(hdfs, dstPath);
        checkAndCreateDir(hdfs, srcPath);

        String filePath = dstPath + "/" +fileName ;
        FileUtil.copyMerge(hdfs, new Path(srcPath), hdfs, new Path(filePath), deleteSrc, conf, null);
        System.out.println("Merge Data Successful into Destination folder!!");

    }


    public static boolean chkIfMerge(Instant start, int merge_interval){
        Instant end = Instant.now();
        Duration timeElapsed = Duration.between(start, end);
        System.out.println("Time taken: "+ timeElapsed.toMinutes() +" minutes");

        if(timeElapsed.toMinutes()> merge_interval) {
            System.out.println("Start to Merge entire data!");
            return true;
        }
        return false;
    }
}
